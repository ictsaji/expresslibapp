

const express = require('express');   // basic express import command

const signrouter = express.Router();

function signrouting(nav)
 {


       signrouter.get('/', function (req, res)
        {
                res.render("libsign",{
                  nav, 
                  title:'library'});
        });

        return signrouter;
}



module.exports = signrouting;