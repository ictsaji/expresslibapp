

const express = require('express');   // basic express import command

const booksrouter = express.Router();

function routernav(nav) {

        var bookss = [

                {
                        title: 'Rithu',
                        author: 'syamaprasad',
                        img: "rithu.jpg",
                        genre: 'romance'
                },

                {
                        title: 'Neena',
                        author: 'laljose',

                        img: "neena.jpg",
                        genre: 'separation'
                },

                {
                        title: 'Mazha',
                        author: 'lenin Rajendran',

                        img: "mazha.jpg",
                        genre: 'classic'
                }


        ]



        booksrouter.get('/', function (req, res) {
                res.render("books.ejs", {
                        nav,
                        title: 'library',
                        bookss: bookss



                });
        });


        booksrouter.get('/:i', function (req, res) {
                const i = req.params.i;
                res.render('book.ejs', {
                        nav,
                        title: 'library',
                        book: bookss[i]


                })

        })



        return booksrouter;
}



module.exports = routernav;