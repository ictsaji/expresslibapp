

const express=require ('express');

const app=new express ();

const nav=  [       {link:'/home',name:'HOME'},
                    {link:'/books',name:'BOOKS'},
                    {link:'/libsign',name:'SIGNIN'},
                    {link:'/liblog',name:'LOGIN'}
            ]

const booksrouter=require('./src/routes/bookroutes')(nav);

const signrouter=require('./src/routes/signroutes')(nav);
const logrouter=require('./src/routes/logroutes')(nav);




app.set ('view engine','ejs');

app.set('views','./src/views');

app.use(express.static('./public'));

app.use('/books', booksrouter);
app.use('/libsign', signrouter);
app.use('/liblog', logrouter);

app.get('/',function (req,res)
                {  res.render("index.ejs",  
                                {      
                                title:'library',
                                nav

                                } 
                        );  

                }
        );

app.get('/home',function (req,res)
                {  res.render("index.ejs",  
                                {      
                                title:'library',
                                nav

                                } 
                            );  

                }
       );


app.listen(1156);